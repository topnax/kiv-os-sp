//
// Created by Stanislav Král on 05.12.2020.
//

#include "../api/api.h"

void handle_error_message(kiv_os::NOS_Error, kiv_os::THandle std_out);
