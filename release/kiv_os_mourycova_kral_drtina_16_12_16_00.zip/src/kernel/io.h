#pragma once

#include "..\api\api.h"

void Handle_IO(kiv_hal::TRegisters &regs);