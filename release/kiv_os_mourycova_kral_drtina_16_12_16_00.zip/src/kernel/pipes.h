#pragma once
#include "pipe.h"
#include "../api/api.h"

std::pair<kiv_os::THandle, kiv_os::THandle> Create_Pipe();
